"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  HomeIcon,
  MagnifyingGlassIcon,
  Bars3Icon,
  XMarkIcon,
  Cog6ToothIcon,
  SunIcon,
  ArrowRightOnRectangleIcon,
} from "@heroicons/react/24/outline";
import { pages } from "@/data/page";

const TopNavigation = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const router = useRouter();

  const filteredPages = pages.filter((page) =>
    page.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    setIsMenuOpen(false);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    setIsSearchOpen(false);
  };

  return (
    <>
      {/* Backdrop blur for all menus */}
      <AnimatePresence>
        {(isMenuOpen || isSearchOpen) && (
          <motion.div
            className="fixed inset-0 bg-opacity-50 backdrop-blur-lg z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              setIsMenuOpen(false);
              setIsSearchOpen(false);
            }}
          ></motion.div>
        )}
      </AnimatePresence>
      
      <motion.div
        initial={{ height: "4rem" }}
        animate={{ height: isMenuOpen ? "16rem" : "4rem" }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="fixed bottom-0 left-0 w-full bg-gray-800 z-50 px-4 py-3 rounded-t-3xl flex flex-col items-center overflow-hidden"
      >
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.25 }}
              className="w-full flex flex-col items-center space-y-2 pb-4"
            >
              <button className="w-full flex items-center px-4 py-3 text-white hover:bg-gray-700 rounded-lg">
                <ArrowRightOnRectangleIcon className="w-6 h-6 mr-2" /> Sign in
              </button>
              <button className="w-full flex items-center px-4 py-3 text-white hover:bg-gray-700 rounded-lg">
                <Cog6ToothIcon className="w-6 h-6 mr-2" /> Settings
              </button>
              <button className="w-full flex items-center px-4 py-3 text-white hover:bg-gray-700 rounded-lg">
                <SunIcon className="w-6 h-6 mr-2" /> Change theme
              </button>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="w-full flex items-center justify-between h-12 mt-auto relative">
          <HomeIcon className="w-7 h-7 text-white fixed bottom-4 left-6" />
          <button onClick={toggleSearch} className="p-1 fixed bottom-4 left-1/2 -translate-x-1/2">
            <MagnifyingGlassIcon className="w-7 h-7 text-white" />
          </button>
          <button onClick={toggleMenu} className="p-1 fixed bottom-4 right-6">
            {isMenuOpen ? (
              <XMarkIcon className="w-7 h-7 text-white" />
            ) : (
              <Bars3Icon className="w-7 h-7 text-white" />
            )}
          </button>
        </div>
      </motion.div>
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            className="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 w-full flex justify-center items-start"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              initial={{ width: 60, height: 20, borderRadius: "10px", y: -50 }}
              animate={{ width: 320, height: 200, borderRadius: "20px", y: 0 }}
              exit={{ width: 60, height: 20, borderRadius: "10px", y: -50 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="bg-gray-800 p-4 shadow-lg relative flex flex-col items-center"
              onClick={(e) => e.stopPropagation()}
            >
              <motion.div className="relative w-full">
                <motion.input
                  initial={{ paddingLeft: "2.5rem" }}
                  animate={{ paddingLeft: "2.5rem" }}
                  exit={{ paddingLeft: "2.5rem" }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  type="text"
                  placeholder="Search..."
                  className="w-full bg-gray-700 text-white p-2 rounded-lg outline-none"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  className="absolute left-2 top-1/2 transform -translate-y-1/2"
                >
                  <MagnifyingGlassIcon className="w-5 h-5 text-white" />
                </motion.div>
              </motion.div>
              <div className="mt-3 w-full max-h-32 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
                {filteredPages.map((page) => (
                  <motion.button
                    key={page.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ duration: 0.25, ease: "easeOut", delay: 0.15 }}
                    className="w-full flex items-center px-4 py-3 text-white hover:bg-gray-700 rounded-lg"
                    onClick={() => {
                      router.push(page.link);
                      setIsSearchOpen(false);
                    }}
                  >
                    {page.name} ({page.type})
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default TopNavigation;