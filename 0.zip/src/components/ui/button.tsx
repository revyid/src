"use client";

import { ButtonHTMLAttributes } from "react";
import { twMerge } from "tailwind-merge";

export function Button({ className, ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={twMerge(
        "px-6 py-3 text-lg font-medium rounded-full shadow-lg transition-all duration-300",
        "bg-white text-black hover:bg-gray-200 active:scale-95",
        className
      )}
      {...props}
    />
  );
}