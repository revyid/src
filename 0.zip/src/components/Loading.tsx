// components/Loading.tsx
"use client";

import { motion } from "framer-motion";

export default function Loading() {
  return (
    <motion.div
      key="loader"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 flex items-center justify-center z-50 bg-white"
    >
      <div className="flex flex-col items-center">
        <motion.div
          initial={{ scale: 0.8, borderRadius: "50%" }}
          animate={{ 
            scale: [0.8, 1.2, 0.8],
            borderRadius: ["50%", "15%", "50%"]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-20 h-20 bg-gradient-to-r from-cyan-400 to-purple-500"
        />
        
        <motion.div 
          className="mt-4 relative h-2 w-40 bg-gray-200 rounded-full overflow-hidden"
        >
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full"
            initial={{ x: "-100%" }}
            animate={{ x: "100%" }}
            transition={{ 
              duration: 1.5, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </motion.div>
      </div>
    </motion.div>
  );
}
