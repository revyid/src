"use client";

import Hero from "@/components/Hero";

export default function Page() {
  return (
    <main>
      <Hero />
    </main>
  );
}
