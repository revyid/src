/* eslint-disable */
import { JWT } from 'google-auth-library';
import { google } from 'googleapis';
import { Readable } from "stream";

// Configuration for Google Drive API
const CREDENTIALS = JSON.parse(process.env.GOOGLE_DRIVE_CREDENTIALS || '{}');
const SCOPES = ['https://www.googleapis.com/auth/drive'];
const USER_IMAGES_FOLDER_ID = process.env.GOOGLE_DRIVE_IMAGES_FOLDER_ID;
const USER_DATA_FOLDER_ID = process.env.GOOGLE_DRIVE_DATA_FOLDER_ID;

// JWT client setup for authentication
const jwtClient = new JWT({
  email: CREDENTIALS.client_email,
  key: CREDENTIALS.private_key,
  scopes: SCOPES,
});

// Initialize the Drive API
const driveService = google.drive({ version: 'v3', auth: jwtClient });

/**
 * Upload a file to Google Drive
 */
export async function uploadFileToDrive(
  fileContent: Buffer,
  fileName: string, 
  mimeType: string,
  folderId: string
): Promise<string> {
  try {
    const response = await driveService.files.create({
      requestBody: {
        name: fileName,
        mimeType: mimeType,
        parents: [folderId]
      },
      media: {
        mimeType: mimeType,
        body: Readable.from(fileContent)
      },
      fields: 'id'
    });

    if (response.data.id) {
      // Make the file publicly accessible
      await driveService.permissions.create({
        fileId: response.data.id,
        requestBody: {
          role: 'reader',
          type: 'anyone'
        }
      });
      
      return response.data.id;
    }
    throw new Error('Failed to upload file to Drive');
  } catch (error) {
    console.error('Error uploading file to Drive:', error);
    throw error;
  }
}

/**
 * Get public URL for a Google Drive file
 */
export function getFilePublicUrl(fileId: string): string {
  return `https://drive.google.com/uc?export=view&id=${fileId}`;
}

/**
 * Upload a JSON file to Google Drive
 */
export async function uploadJsonToDrive(data: any, fileName: string): Promise<string> {
  const content = Buffer.from(JSON.stringify(data, null, 2));
  return uploadFileToDrive(content, fileName, 'application/json', USER_DATA_FOLDER_ID!);
}

/**
 * Upload an image file to Google Drive
 */
export async function uploadImageToDrive(imageBuffer: Buffer, fileName: string, mimeType: string): Promise<string> {
  return uploadFileToDrive(imageBuffer, fileName, mimeType, USER_IMAGES_FOLDER_ID!);
}

/**
 * Find a file in Google Drive by name and folder
 */
export async function findFileByName(fileName: string, folderId: string): Promise<any | null> {
  try {
    const response = await driveService.files.list({
      q: `name='${fileName}' and '${folderId}' in parents and trashed=false`,
      fields: 'files(id, name)',
    });

    if (response.data.files && response.data.files.length > 0) {
      return response.data.files[0];
    }
    return null;
  } catch (error) {
    console.error('Error finding file in Drive:', error);
    throw error;
  }
}

/**
 * Get a file's content from Google Drive
 */
export async function getFileContent(fileId: string): Promise<any> {
  try {
    const response = await driveService.files.get({
      fileId: fileId,
      alt: 'media'
    }, { responseType: 'arraybuffer' });
    
    return response.data;
  } catch (error) {
    console.error('Error getting file content from Drive:', error);
    throw error;
  }
}

/**
 * Update a file's content in Google Drive
 */
export async function updateFileContent(fileId: string, content: any, mimeType: string): Promise<void> {
  try {
    await driveService.files.update({
      fileId: fileId,
      media: {
        mimeType: mimeType,
        body: content
      }
    });
  } catch (error) {
    console.error('Error updating file in Drive:', error);
    throw error;
  }
}

/**
 * Get a user data file from Google Drive
 */
export async function getUserDataFile(email: string): Promise<any | null> {
  try {
    const fileName = `${email.replace(/[@.]/g, '_')}.json`;
    const file = await findFileByName(fileName, USER_DATA_FOLDER_ID!);
    
    if (file && file.id) {
      const content = await getFileContent(file.id);
      // Convert array buffer to string and parse JSON
      const jsonContent = Buffer.from(content).toString('utf8');
      return JSON.parse(jsonContent);
    }
    return null;
  } catch (error) {
    console.error('Error getting user data file:', error);
    return null;
  }
}

/**
 * Save or update user data to Google Drive
 */
export async function saveUserData(email: string, userData: any): Promise<void> {
  try {
    const fileName = `${email.replace(/[@.]/g, '_')}.json`;
    const file = await findFileByName(fileName, USER_DATA_FOLDER_ID!);
    const content = Buffer.from(JSON.stringify(userData, null, 2));
    
    if (file && file.id) {
      // Update existing file
      await updateFileContent(file.id, content, 'application/json');
    } else {
      // Create new file
      await uploadFileToDrive(content, fileName, 'application/json', USER_DATA_FOLDER_ID!);
    }
  } catch (error) {
    console.error('Error saving user data:', error);
    throw error;
  }
}

// Export all necessary functions and the drive service
export { driveService, google };
