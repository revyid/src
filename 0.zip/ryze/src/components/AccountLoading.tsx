// @/components/Loading.tsx
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const Loading: React.FC = () => {
  const [loadingMessage, setLoadingMessage] = useState('Authenticating your session');
  
  // Array of loading messages to cycle through
  const loadingMessages = [
    'Authenticating your session',
    'Fetching account information',
    'Preparing your dashboard',
    'Syncing profile data',
    'Loading your preferences',
    'Checking credentials',
    'Connecting to database',
    'Verifying access rights'
  ];
  
  useEffect(() => {
    // Cycle through loading messages
    const interval = setInterval(() => {
      setLoadingMessage(prevMessage => {
        const currentIndex = loadingMessages.indexOf(prevMessage);
        const nextIndex = (currentIndex + 1) % loadingMessages.length;
        return loadingMessages[nextIndex];
      });
    }, 2500);
    
    return () => clearInterval(interval);
  }, []);
  
  // Staggered dots animation
  const dotsVariants = {
    initial: {
      transition: {
        staggerChildren: 0.2,
      },
    },
    animate: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  };
  
  const dotVariant = {
    initial: { y: 0 },
    animate: { 
      y: [0, -10, 0],
      transition: {
        duration: 0.6,
        repeat: Infinity,
        repeatType: 'loop' as const,
      }
    },
  };
  
  // Blob morphing animation
  const blobVariants = {
    initial: { 
      borderRadius: '60% 40% 30% 70%/60% 30% 70% 40%',
      scale: 1,
    },
    animate: { 
      borderRadius: ['60% 40% 30% 70%/60% 30% 70% 40%', 
                     '30% 60% 70% 40%/50% 60% 30% 60%',
                     '40% 60% 30% 70%/70% 40% 60% 30%',
                     '60% 40% 30% 70%/60% 30% 70% 40%'],
      scale: [1, 1.05, 0.95, 1],
      transition: {
        duration: 8,
        repeat: Infinity,
        repeatType: 'loop' as const,
      }
    },
  };
  
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex flex-col items-center justify-center">
      <div className="text-center px-4">
        {/* Animated blob background */}
        <div className="relative mb-12 mx-auto">
          <motion.div
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-gradient-to-r from-blue-400 to-purple-500 opacity-30 blur-lg"
            variants={blobVariants}
            initial="initial"
            animate="animate"
          />
          
          {/* Logo/icon in center */}
          <motion.div 
            className="relative z-10 w-24 h-24 mx-auto bg-white rounded-full shadow-lg flex items-center justify-center"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 20, delay: 0.2 }}
          >
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg transform rotate-45 flex items-center justify-center">
              <svg className="w-8 h-8 text-white transform -rotate-45" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
          </motion.div>
        </div>
        
        {/* Loading message */}
        <motion.h2 
          className="text-xl md:text-2xl font-medium text-gray-800 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {loadingMessage}
        </motion.h2>
        
        {/* Animated dots */}
        <motion.div 
          className="flex space-x-2 justify-center"
          variants={dotsVariants}
          initial="initial"
          animate="animate"
        >
          {[0, 1, 2].map((dot) => (
            <motion.div
              key={dot}
              className="w-3 h-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full"
              variants={dotVariant}
            />
          ))}
        </motion.div>
        
        {/* Subtle hint */}
        <motion.p 
          className="text-sm text-gray-500 mt-16 max-w-xs mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
        >
          This may take a moment while we prepare your personalized experience
        </motion.p>
      </div>
    </div>
  );
};

export default Loading;