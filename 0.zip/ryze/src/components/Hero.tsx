"use client";

import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section className="flex flex-col justify-center items-center text-center h-screen px-8 bg-gradient-to-br from-yellow-400 via-pink-500 to-purple-600 text-white relative overflow-hidden">
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-6xl md:text-7xl font-extrabold drop-shadow-lg"
      >
        Design with Impact
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-xl md:text-2xl mt-4 max-w-2xl drop-shadow-md"
      >
        Simplicity meets boldness. Elevate your brand with a stunning minimalistic approach.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2 }}
        className="mt-8"
      >
        <Button className="bg-white text-black px-6 py-3 text-lg font-medium rounded-full shadow-lg hover:bg-gray-200">
          Get Started
        </Button>
      </motion.div>
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1.5, opacity: 0.1 }}
          transition={{ duration: 2 }}
          className="w-96 h-96 bg-white rounded-full absolute -top-20 -left-20"
        />
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 2, opacity: 0.15 }}
          transition={{ duration: 2 }}
          className="w-80 h-80 bg-white rounded-full absolute bottom-10 right-10"
        />
      </div>
    </section>
  );
}