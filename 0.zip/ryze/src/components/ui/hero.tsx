import Button from './button';

export default function Hero() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-blue-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="md:w-1/2 space-y-6">
            <h1 className="heading-1 text-blue-900 dark:text-blue-100">
              Build amazing experiences with Next.js v15
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Create modern web applications with the latest features and optimized performance.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button variant="primary" size="lg">
                Get Started
              </Button>
              <Button variant="outline" size="lg">
                Learn More
              </Button>
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="relative h-80 w-full rounded-xl bg-gradient-to-br from-blue-400 to-purple-500 shadow-2xl">
              <div className="absolute inset-0 flex items-center justify-center text-white">
                <p className="text-2xl font-bold">Hero Image</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}