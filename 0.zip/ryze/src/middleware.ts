// middleware.ts
import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { NextRequest } from "next/server";

export async function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;

  // Define which paths are protected (require authentication)
  const protectedPaths = ["/dashboard", "/profile", "/settings"];
  const isPathProtected = protectedPaths.some((prefix) => 
    path.startsWith(prefix)
  );

  if (isPathProtected) {
    const token = await getToken({ req });

    // Redirect to join if not authenticated
    if (!token) {
      const url = new URL(`/join`, req.url);
      url.searchParams.set("callbackUrl", path);
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

// Configure which paths trigger the middleware
export const config = {
  matcher: ["/dashboard/:path*", "/profile/:path*", "/settings/:path*"],
};