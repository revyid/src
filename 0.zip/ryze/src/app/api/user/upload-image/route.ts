/* eslint-disable */
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { uploadImageToDrive, getFilePublicUrl, findFileByName, driveService } from "@/utils/google-drive-service";
import { saveUserData, getUserDataFile } from "@/utils/google-drive-service";

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const email = session.user?.email!;
    const userData = await getUserDataFile(email);
    if (!userData) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const formData = await request.formData();
    const file = formData.get("file");

    if (!file || !(file instanceof Blob)) {
      return NextResponse.json({ error: "No valid file uploaded" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const fileName = `${email.replace(/[@.]/g, "_")}_${Date.now()}`;
    const mimeType = file.type;

    // Hapus gambar lama jika ada
    if (userData.profileImageUrl) {
      const oldFileId = userData.profileImageUrl.split("id=")[1]; // Ekstrak fileId dari URL
      if (oldFileId) {
        try {
          await driveService.files.delete({ fileId: oldFileId });
        } catch (error) {
          console.warn("Gagal menghapus gambar lama:", error);
        }
      }
    }

    // Upload gambar baru
    const fileId = await uploadImageToDrive(buffer, fileName, mimeType);
    const fileUrl = getFilePublicUrl(fileId);

    // Update profileImageUrl di user data
    userData.profileImageUrl = fileUrl;
    await saveUserData(email, userData);

    return NextResponse.json({ success: true, fileUrl });
  } catch (error) {
    console.error("Error uploading image:", error);
    return NextResponse.json({ error: "Failed to upload image" }, { status: 500 });
  }
}
