// @/app/api/user/create-profile/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { saveUserData, getUserDataFile } from "@/utils/google-drive-service";

export async function POST(request: NextRequest) {
  // Verify user is authenticated
  const session = await getServerSession(authOptions);
  
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { email, userId, displayName, profileImageUrl } = await request.json();

    if (!email || !userId || !displayName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check if user with this email already exists
    const existingUserByEmail = await getUserDataFile(email);
    if (existingUserByEmail) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 400 });
    }

    // Check if userId is already taken
    // This is a simplified approach - for production, you'd need a more efficient way to check
    const existingUserWithId = false;
    // This would involve a more complex query to search all user files for the userId
    
    if (existingUserWithId) {
      return NextResponse.json({ error: "This User ID is already taken" }, { status: 400 });
    }

    // Create new user
    const newUser = {
      email,
      userId,
      displayName,
      profileImageUrl: profileImageUrl || "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save user data to Google Drive
    await saveUserData(email, newUser);

    return NextResponse.json({ success: true, user: newUser });
  } catch (error) {
    console.error("Error creating user profile:", error);
    return NextResponse.json({ error: "Failed to create user profile" }, { status: 500 });
  }
}