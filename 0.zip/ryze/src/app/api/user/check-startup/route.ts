// @/app/api/user/check-startup/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getUserDataFile } from "@/utils/google-drive-service";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const email = searchParams.get("email");

  if (!email) {
    return NextResponse.json({ error: "Email is required" }, { status: 400 });
  }

  try {
    // Get user data from Google Drive
    const userData = await getUserDataFile(email);
    
    // Check if user with this email exists
    const isSetupComplete = !!userData;

    return NextResponse.json({ isSetupComplete });
  } catch (error) {
    console.error("Error checking user setup status:", error);
    return NextResponse.json({ error: "Failed to check user setup status" }, { status: 500 });
  }
}