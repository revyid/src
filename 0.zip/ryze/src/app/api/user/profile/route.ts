/* eslint-disable */
// @/app/api/user/profile/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { 
  getUserDataFile, 
  saveUserData, 
  driveService,
  google 
} from "@/utils/google-drive-service";
import { JWT } from 'google-auth-library';

// JWT client from environment variables
const CREDENTIALS = JSON.parse(process.env.GOOGLE_DRIVE_CREDENTIALS || '{}');
const SCOPES = ['https://www.googleapis.com/auth/drive'];
const USER_DATA_FOLDER_ID = process.env.GOOGLE_DRIVE_DATA_FOLDER_ID;

// JWT client setup for authentication
const jwtClient = new JWT({
  email: CREDENTIALS.client_email,
  key: CREDENTIALS.private_key,
  scopes: SCOPES,
});

// Function to find user by userId
async function findUserByUserId(userId: string): Promise<any | null> {
  try {
    // List all files in the user data folder
    const response = await driveService.files.list({
      q: `'${USER_DATA_FOLDER_ID}' in parents and trashed=false`,
      fields: 'files(id, name)',
    });

    if (response.data.files && response.data.files.length > 0) {
      for (const file of response.data.files) {
        if (file.id) {
          try {
const content = await driveService.files.get({
  fileId: file.id,
  alt: 'media'
});

// Debugging output
console.log("File Content:", content.data);

// Pastikan datanya bisa diakses
const userData = typeof content.data === "string" ? JSON.parse(content.data) : content.data;

if (userData && typeof userData === "object" && "userId" in userData && 
    userData.userId.toLowerCase() === userId.toLowerCase()) {
  return userData;
}

          } catch (err) {
            // Continue to next file if there's an error reading this one
            console.error(`Error reading file ${file.name}:`, err);
          }
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Error finding user by userId:", error);
    return null;
  }
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const email = searchParams.get("email");
  const userId = searchParams.get("userId");

  if (!email && !userId) {
    return NextResponse.json({ error: "Either email or userId is required" }, { status: 400 });
  }

  try {
    let user;

    if (email) {
      user = await getUserDataFile(email);
    } else if (userId) {
      user = await findUserByUserId(userId);
    }

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // If requesting by userId, return only public info
    if (userId && !email) {
      const { email, ...publicInfo } = user;
      return NextResponse.json(publicInfo);
    }

    // If requesting by email, verify session
    const session = await getServerSession(authOptions);
    if (!session || session.user?.email !== email) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    return NextResponse.json(user);
  } catch (error) {
    console.error("Error fetching user profile:", error);
    return NextResponse.json({ error: "Failed to fetch user profile" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  // Verify user is authenticated
  const session = await getServerSession(authOptions);
  
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { email, userId, displayName, profileImageUrl } = await request.json();

    if (!email || !userId || !displayName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Verify the user is updating their own profile
    if (session.user?.email !== email) {
      return NextResponse.json({ error: "You can only update your own profile" }, { status: 403 });
    }

    // Get existing user
    const existingUser = await getUserDataFile(email);
    if (!existingUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Check if new userId is already taken by another user
    if (existingUser.userId.toLowerCase() !== userId.toLowerCase()) {
      const existingUserWithId = await findUserByUserId(userId);
      if (existingUserWithId && existingUserWithId.email !== email) {
        return NextResponse.json({ error: "This User ID is already taken" }, { status: 400 });
      }
    }

    // Update user
    const updatedUser = {
      ...existingUser,
      userId,
      displayName,
      profileImageUrl: profileImageUrl || existingUser.profileImageUrl,
      updatedAt: new Date().toISOString(),
    };

    // Save updated user data
    await saveUserData(email, updatedUser);

    return NextResponse.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error("Error updating user profile:", error);
    return NextResponse.json({ error: "Failed to update user profile" }, { status: 500 });
  }
}