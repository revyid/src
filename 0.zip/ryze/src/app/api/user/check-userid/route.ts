/* eslint-disable */
// @/app/api/check-userid/route.ts
import { NextRequest, NextResponse } from "next/server";
import { google } from 'googleapis';
import { JWT } from 'google-auth-library';

// JWT client from environment variables
const CREDENTIALS = JSON.parse(process.env.GOOGLE_DRIVE_CREDENTIALS || '{}');
const SCOPES = ['https://www.googleapis.com/auth/drive'];
const USER_DATA_FOLDER_ID = process.env.GOOGLE_DRIVE_DATA_FOLDER_ID;

// JWT client setup for authentication
const jwtClient = new JWT({
  email: CREDENTIALS.client_email,
  key: CREDENTIALS.private_key,
  scopes: SCOPES,
});

// Initialize the Drive API
const driveService = google.drive({ version: 'v3', auth: jwtClient });

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const userId = searchParams.get("userid");

  if (!userId) {
    return NextResponse.json({ error: "User ID is required" }, { status: 400 });
  }

  try {
    // List all files in the user data folder
    const response = await driveService.files.list({
      q: `'${USER_DATA_FOLDER_ID}' in parents and trashed=false`,
      fields: 'files(id, name, properties)',
    });

    // Check each file to see if it contains a user with this userId
    let userExists = false;
    
    if (response.data.files && response.data.files.length > 0) {
      for (const file of response.data.files) {
        if (file.properties && file.properties.userId) {
          if (file.properties.userId.toLowerCase() === userId.toLowerCase()) {
            userExists = true;
            break;
          }
        }
      }
    }

    return NextResponse.json({ available: !userExists });
  } catch (error) {
    console.error("Error checking user ID availability:", error);
    return NextResponse.json({ error: "Failed to check user ID availability" }, { status: 500 });
  }
}