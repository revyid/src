// @/app/dashboard/page.tsx
/* eslint-disable */
"use client";

import { useState, useEffect, useRef } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Image from "next/image";
import { signOut } from "next-auth/react";
import Loading from "@/components/AccountLoading";

export default function Dashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [userId, setUserId] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userIdAvailable, setUserIdAvailable] = useState(true);
  const [userIdChecking, setUserIdChecking] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/join");
    } else if (status === "authenticated" && session?.user?.email && !user) {
      checkUserSetup();
    }
  }, [status, session, router]);

  const checkUserSetup = async () => {
    if (!session?.user?.email) return;
    
    try {
      const response = await fetch(`/api/user/check-startup?email=${session.user.email}`);
      const data = await response.json();
      
      if (!data.isSetupComplete) {
        // User profile doesn't exist, redirect to startup
        router.push("/account/startup");
      } else if (!user) {
        // User exists, fetch profile
        fetchUserProfile();
      }
    } catch (error) {
      console.error("Error checking user setup:", error);
      setLoading(false);
    }
  };

  // Check user ID availability when editing
  useEffect(() => {
    if (!isEditing || userId === user?.userId) return;

    const checkUserIdAvailability = async () => {
      if (userId.length < 3) {
        setUserIdAvailable(false);
        return;
      }

      setUserIdChecking(true);
      try {
        const response = await fetch(`/api/user/check-userid?userid=${userId}`);
        const data = await response.json();
        setUserIdAvailable(data.available);
      } catch (error) {
        console.error("Error checking userId availability:", error);
        setUserIdAvailable(false);
      } finally {
        setUserIdChecking(false);
      }
    };

    const debounceTimer = setTimeout(() => {
      if (userId) {
        checkUserIdAvailability();
      }
    }, 500);

    return () => clearTimeout(debounceTimer);
  }, [userId, isEditing, user]);

  const fetchUserProfile = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/user/profile?email=${session?.user?.email}`);
      
      if (response.status === 404) {
        // User profile doesn't exist, redirect to startup
        router.push("/account/startup");
        return;
      }
      
      if (!response.ok) {
        throw new Error("Failed to fetch user profile");
      }
      
      const userData = await response.json();
      setUser(userData);
      setUserId(userData.userId);
      setDisplayName(userData.displayName);
      setImagePreview(userData.profileImageUrl);
    } catch (error) {
      console.error("Error fetching user profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditToggle = () => {
    if (isEditing) {
      // Cancel editing, reset values
      setUserId(user.userId);
      setDisplayName(user.displayName);
      setImagePreview(user.profileImageUrl);
      setProfileImage(null);
    }
    setIsEditing(!isEditing);
    setError(null);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
 // Validate file size (max 5MB)
if (file.size > 5 * 1024 * 1024) {
  setError("Image size should be less than 5MB");
  return;
}
      
      // Validate file type
      if (!file.type.match(/image\/(jpeg|jpg|png|gif)/)) {
        setError("Only JPEG, PNG, and GIF images are allowed");
        return;
      }

      setProfileImage(file);
      setImagePreview(URL.createObjectURL(file));
      setError(null);
    }
  };

  const handleSaveProfile = async () => {
    if (!userId || !displayName) {
      setError("User ID and Display Name are required");
      return;
    }

    if (!userIdAvailable && userId !== user.userId) {
      setError("Please choose a different User ID");
      return;
    }

    setSaving(true);
    setError(null);

    try {
      // Upload profile image to Google Drive if provided
      let profileImageUrl = user.profileImageUrl;
      if (profileImage) {
        const formData = new FormData();
        formData.append('file', profileImage);
        
        const uploadResponse = await fetch('/api/user/upload-image', {
          method: 'POST',
          body: formData
        });
        
        if (!uploadResponse.ok) {
          throw new Error('Failed to upload profile image');
        }
        
        const { imageUrl } = await uploadResponse.json();
        profileImageUrl = imageUrl;
      }

      // Update user profile
      const response = await fetch("/api/user/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: session?.user?.email,
          userId,
          displayName,
          profileImageUrl,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to update profile");
      }

      const updatedUser = await response.json();
      setUser(updatedUser.user);
      setIsEditing(false);
    } catch (error: any) {
      console.error("Error updating profile:", error);
      setError(error.message || "An error occurred while updating your profile");
    } finally {
      setSaving(false);
    }
  };

  if (status === "loading" || loading) {
    return <Loading />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full md:w-1/4"
          >
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex flex-col items-center">
                <div className="relative w-28 h-28 rounded-full overflow-hidden border-4 border-white shadow-md mb-4">
                  {user?.profileImageUrl ? (
                    <Image
                      src={user.profileImageUrl}
                      alt={user.displayName}
                      fill
                      className="object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white text-2xl font-bold">
                      {user?.displayName?.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <h2 className="text-xl font-bold">{user?.displayName}</h2>
                <p className="text-gray-500 text-sm">@{user?.userId}</p>
              </div>

              <div className="mt-6 space-y-2">
                <button
                  onClick={() => router.push(`/user/${user?.userId}`)}
                  className="w-full py-2 px-4 bg-gray-100 rounded-lg text-gray-700 flex items-center hover:bg-gray-200 transition-colors"
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  View Public Profile
                </button>
                
                <button
                  onClick={handleEditToggle}
                  className="w-full py-2 px-4 bg-gray-100 rounded-lg text-gray-700 flex items-center hover:bg-gray-200 transition-colors"
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                  </svg>
                  {isEditing ? "Cancel Editing" : "Edit Profile"}
                </button>
                
                <button
                  onClick={() => signOut({ callbackUrl: "/" })}
                  className="w-full py-2 px-4 bg-gray-100 rounded-lg text-gray-700 flex items-center hover:bg-gray-200 transition-colors"
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  Sign Out
                </button>
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="w-full md:w-3/4"
          >
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent mb-6">
                {isEditing ? "Edit Your Profile" : "Your Profile"}
              </h1>

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 rounded-lg bg-red-50 text-red-600 text-sm mb-6"
                >
                  {error}
                </motion.div>
              )}

              {isEditing ? (
                <div className="space-y-6">
                  <div>
                    <label htmlFor="profileImage" className="block text-sm font-medium text-gray-700 mb-1">
                      Profile Image
                    </label>
                    <div className="flex items-center space-x-6">
                      <div 
                        onClick={() => fileInputRef.current?.click()} 
                        className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-blue-500 transition-colors"
                      >
                        {imagePreview ? (
                          <Image
                            src={imagePreview}
                            alt="Profile preview"
                            fill
                            className="object-cover"
                          />
                        ) : (
                          <div className="text-gray-400">
                            <svg className="h-8 w-8" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                              <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          </div>
                        )}
                      </div>
                      
                      <input
                        type="file"
                        id="profileImage"
                        ref={fileInputRef}
                        onChange={handleImageChange}
                        className="hidden"
                        accept="image/jpeg, image/png, image/gif"
                      />
                      
                      <div className="text-sm text-gray-500">
                        <p>Click to upload a new image</p>
                        <p>JPG, PNG or GIF (max. 5MB)</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="userId" className="block text-sm font-medium text-gray-700 mb-1">
                      User ID
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="userId"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                        className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                        maxLength={30}
                      />
                      {userId && userId !== user.userId && (
                        <div className="absolute right-3 top-3">
                          {userIdChecking ? (
                            <svg className="animate-spin h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                          ) : userIdAvailable ? (
                            <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          )}
                        </div>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-gray-500">
                      Your public profile URL will be: ryzetwo.vercel.app/user/{userId}
                    </p>
                  </div>

                  <div>
                    <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-1">
                      Display Name
                    </label>
                    <input
                      type="text"
                      id="displayName"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="block w-full px-4 py-3 rounded-lg border border-gray-300 text-blue-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                      maxLength={50}
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      This is how your name will appear to others
                    </p>
                  </div>

                  <div className="flex justify-end space-x-4 pt-4">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      onClick={handleEditToggle}
                      className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      onClick={handleSaveProfile}
                      disabled={saving}
                      className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg text-white hover:opacity-90 transition-opacity"
                    >
                      {saving ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Saving
                        </span>
                      ) : (
                        "Save Changes"
                      )}
                    </motion.button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-700 mb-2">User ID</h3>
                    <p className="text-lg text-gray-600">@{user?.userId}</p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-700 mb-2">Display Name</h3>
                    <p className="text-lg text-gray-600">{user?.displayName}</p>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-medium text-gray-700 mb-2">Public Profile</h3>
                    <p className="text-lg break-words">
                      <a 
                        href={`/user/${user?.userId}`} 
                        className="text-blue-600 hover:underline"
                      >
                        ryzetwo.vercel.app/user/{user?.userId}
                      </a>
                    </p>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}