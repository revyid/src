import Header from '@/components/sections/header';
import Hero from '@/components/ui/hero';
import Features from '@/components/sections/features';
import Contact from '@/components/sections/contact';
import Footer from '@/components/ui/footer';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Features />
      <Contact />
      <Footer />
    </main>
  );
}