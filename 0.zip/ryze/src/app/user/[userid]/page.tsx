/* eslint-disable */
"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import Loading from "@/components/Loading";

export default function UserProfile() {
  const params = useParams();
  const userId = params.userid as string;
  
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserProfile = async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/user/profile?userId=${userId}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setError("User not found");
          } else {
            throw new Error("Failed to fetch user profile");
          }
          return;
        }
        
        const userData = await response.json();
        setUser(userData);
      } catch (error) {
        console.error("Error fetching user profile:", error);
        setError("Failed to load user profile");
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchUserProfile();
    }
  }, [userId]);

  if (loading) {
    return <Loading />;
  }

  if (error || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gray-100">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          <h1 className="text-2xl font-bold text-gray-700 mb-2">
            {error === "User not found" ? "User Not Found" : "Error Loading Profile"}
          </h1>
          <p className="text-gray-500 mb-6">
            {error === "User not found" 
              ? `We couldn't find a user with the ID "${userId}".`
              : "There was a problem loading this user profile."}
          </p>
          <Link href="/">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:opacity-90"
            >
              Go Home
            </motion.button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-xl shadow-lg overflow-hidden"
        >
          <div className="relative h-48 bg-blue-500">
            <div className="absolute -bottom-16 left-8">
              <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-md">
                {user.profileImageUrl ? (
                  <Image src={user.profileImageUrl} alt={user.displayName} fill className="object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-300 text-3xl font-bold">
                    {user.displayName.charAt(0).toUpperCase()}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="pt-20 px-8 pb-8">
            <h1 className="text-3xl font-bold">{user.displayName}</h1>
            <p className="text-gray-500">@{user.userId}</p>
            <div className="mt-6">
              <h3 className="font-medium text-gray-700">Profile Created</h3>
              <p className="text-gray-800">
                {new Date(user.createdAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
