// app/layout.tsx
"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import TopNavigation from "@/components/NavBar";
import Loading from "@/components/Loading";
import { AuthProvider } from "@/app/providers/auth-provider";
import "./globals.css";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <html lang="en">
      <body>
       <AuthProvider>
        <AnimatePresence mode="wait">
          {loading ? <Loading /> : (
            <motion.div
              key="content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {children}
              <TopNavigation />
            </motion.div>
          )}
        </AnimatePresence>
       </AuthProvider>
      </body>
    </html>
  );
}
