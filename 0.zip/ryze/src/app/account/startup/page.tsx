// app/account/startup/page.tsx
/* eslint-disable */
"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Loading from "@/components/Loading";

export default function AccountStartup() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [userId, setUserId] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [userIdAvailable, setUserIdAvailable] = useState(true);
  const [userIdChecking, setUserIdChecking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState(1);

  // Check if user already completed setup
  useEffect(() => {
    const checkUserSetup = async () => {
      if (status === "authenticated" && session?.user?.email) {
        try {
          const response = await fetch(`/api/user/check-setup?email=${session.user.email}`);
          const data = await response.json();
          
          if (data.isSetupComplete) {
            router.push("/dashboard");
          }
        } catch (error) {
          console.error("Error checking user setup:", error);
        }
      } else if (status === "unauthenticated") {
        router.push("/join");
      }
    };

    checkUserSetup();
  }, [status, session, router]);

  // Handle user ID availability check
  useEffect(() => {
    const checkUserIdAvailability = async () => {
      if (userId.length < 3) {
        setUserIdAvailable(false);
        return;
      }

      setUserIdChecking(true);
      try {
        const response = await fetch(`/api/user/check-userid?userid=${userId}`);
        const data = await response.json();
        setUserIdAvailable(data.available);
      } catch (error) {
        console.error("Error checking userId availability:", error);
        setUserIdAvailable(false);
      } finally {
        setUserIdChecking(false);
      }
    };

    const debounceTimer = setTimeout(() => {
      if (userId) {
        checkUserIdAvailability();
      }
    }, 500);

    return () => clearTimeout(debounceTimer);
  }, [userId]);


  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    if (!userId || !displayName) {
      setError("All fields are required");
      setIsSubmitting(false);
      return;
    }

    if (!userIdAvailable) {
      setError("Please choose a different User ID");
      setIsSubmitting(false);
      return;
    }

    try {
      // Create the user profile
      const response = await fetch("/api/user/create-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: session?.user?.email,
          userId,
          displayName,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || "Failed to create profile");
      }

      // Redirect to dashboard on success
      router.push("/dashboard");
    } catch (error: any) {
      console.error("Error creating profile:", error);
      setError(error.message || "An error occurred while creating your profile");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading state
  if (status === "loading") {
    return <Loading />;
  }

  // Next step handler
  const goToNextStep = () => {
    if (step === 1 && (!userId || !userIdAvailable)) {
      setError("Please enter a valid and available User ID");
      return;
    }
    
    if (step === 2 && !displayName) {
      setError("Please enter your Display Name");
      return;
    }
    
    setError(null);
    setStep(step + 1);
  };

  // Previous step handler
  const goToPreviousStep = () => {
    setError(null);
    setStep(step - 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-xl w-full bg-white rounded-2xl shadow-xl overflow-hidden"
      >
        {/* Progress Bar */}
        <div className="w-full h-2 bg-gray-100">
          <motion.div
            initial={{ width: `${(step - 1) * 33.33}%` }}
            animate={{ width: `${step * 33.33}%` }}
            transition={{ duration: 0.5 }}
            className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
          />
        </div>

        <div className="p-8">
          <div className="text-center mb-8">
            <motion.h1
              initial={{ y: -10 }}
              animate={{ y: 0 }}
              className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent"
            >
              Complete Your Profile
            </motion.h1>
            <p className="text-gray-500 mt-2">
              {step === 1 && "Choose a unique user ID for your public profile"}
              {step === 2 && "Tell us how you want to be known"}
            </p>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 rounded-lg bg-red-50 text-red-600 text-sm mb-6"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit}>
            {/* Step 1: User ID */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
              >
                <div className="space-y-4">
                  <div>
                    <label htmlFor="userId" className="block text-sm font-medium text-gray-700 mb-1">
                      User ID
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="userId"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                        className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-gray-700"
                        placeholder="yourname"
                        maxLength={30}
                      />
                      {userId && (
                        <div className="absolute right-3 top-3">
                          {userIdChecking ? (
                            <svg className="animate-spin h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                          ) : userIdAvailable ? (
                            <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          )}
                        </div>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-gray-500">
                      {userId ? (
                        userIdAvailable ? (
                          "This User ID is available!"
                        ) : (
                          "This User ID is already taken or invalid."
                        )
                      ) : (
                        "Choose a unique identifier (letters, numbers, hyphens, underscores only)"
                      )}
                    </p>
                    {userId && (
                      <p className="mt-2 text-sm text-blue-600">
                        Your public profile will be: ryzetwo.vercel.app/user/{userId}
                      </p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: Display Name */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
              >
                <div>
                  <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                    placeholder="Your Name"
                    maxLength={50}
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    This is how your name will appear to others
                  </p>
                </div>
              </motion.div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-10">
              {step > 1 ? (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={goToPreviousStep}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Back
                </motion.button>
              ) : (
                <div></div>
              )}

              {step < 2 ? (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="button"
                  onClick={goToNextStep}
                  className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg text-white hover:opacity-90 transition-opacity"
                >
                  Continue
                </motion.button>
              ) : (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg text-white hover:opacity-90 transition-opacity"
                >
                  {isSubmitting ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Completing Setup
                    </span>
                  ) : (
                    "Complete Setup"
                  )}
                </motion.button>
              )}
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}