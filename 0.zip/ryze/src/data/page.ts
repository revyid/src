export type Page = {
  id: number;
  name: string;
  type: string;
  link: string;
};

export const pages: Page[] = [
  { id: 1, name: "Home", type: "main", link: "/" },
  { id: 2, name: "About", type: "info", link: "/about" },
  { id: 3, name: "Services", type: "info", link: "/services" },
  { id: 4, name: "Contact", type: "info", link: "/contact" },
];
